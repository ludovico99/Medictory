package logic.ingegnerizzazione;

public interface Observer {
	public void update();
}
