package logic.view;

import logic.model.Sessione;

public interface GraphicController{
	public void setData(Sessione s);
}
