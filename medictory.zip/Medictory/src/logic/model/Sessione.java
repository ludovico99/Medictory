package logic.model;


public abstract class Sessione {
	protected String username;
	
		
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
 
}
